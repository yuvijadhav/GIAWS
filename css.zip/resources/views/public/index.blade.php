@extends('layouts.app')

@section('content')
<title>Global Competitor Analysis and Market Research Reports</title>
<meta name="description" content="AGet the most accurate Market Research and Competitor Analysis Reports from our comprehensive storage of reports bank, covering all global industries & markets.">
<meta name="keywords" content="competitor analysis, market research report">

<!-- Trending Products Area Start Here -->
<head>
    <script type="text/javascript">

        function chooseCategory(data){
            var id=data;
            console.log(data);
            var x=document.getElementById("id1").submit();
        }

    </script>
    <style type="text/css">
        .calibri{
            font-family:"calibri";
        }
        #cursor{
            cursor: pointer;
        }
        @media only screen and (max-width: 500px) {
            #index-padding1{
                margin-left: 20px;
                margin-right: 20px;
                margin-top: 20px;
            }
        }
        a div span{
            color:#000;
        }
        a .latest-home-report{
            border: none;
        }
        .single-item-grid .item-img img{
            height: 50px;
        }
    </style>
</head>
<div class="container-fluid" align="left" style="text-align: left;background: url(images/bg5.jpg); background-size: cover;">
    <div class="main-banner2-wrapper" align="left">                       
        <h1 class="welcome" id="search-font1" style="font-family:'Arial Narrow;' text-align:left;word-spacing: 0px; letter-spacing: 0px;">A platform of extensive market reports to cater your specific needs.</h1>
        <h3 id="color-white" class="desktop-only" id="index-search-margin-bottom">Your search for the most accurate market research reports ends here.</h3>
        <div class="col-md-12 search-box">
            <form class="form-inline" id="search-form" method="post" action="reports">
                <center>
                    <div class="col-md-8 col-md-offset-2 search-background">
                        <div class="form-group col-md-10 col-xs-9">
                            <input type="text" id="search" name="search" placeholder="Search Reports . . ." class="form-control">
                        </div>
                        <button type="submit" class="btn btn-default pull-left col-md-2 col-xs-3" id="btn-search">Search</button>
                    </div>    
                </center>
            </form>
        </div>

                        <!-- <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="why-choose-box">                   
                    <h3 class="block-title">1M +</h3>
                    <p style="color:#fff">Market Research reports repository</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="why-choose-box">                   
                    <h3 class="block-title">50+</h3>
                    <p style="color:#fff">Clients in Fortune 500</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="why-choose-box">

                    <h3 class="block-title">78</h3>
                    <p style="color:#fff">Strategic publishers</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="why-choose-box">

                    <h3 class="block-title">3000+</h3>
                    <p style="color:#fff">Client inquiries in 2016</p>
                </div>
            </div>
        </div> -->
    </div>
</div>
<div class="product-page-list bg-secondary section-space-bottom col-lg-12 col-md-12 col-xs-12">

    <div class="container" style="padding-bottom: 40px;">
        <div class="col-lg-12 col-md-12 col-xs-12 no-padding" style="margin-bottom: 30px; margin-top:30px;">  
            <div class="col-lg-12 col-md-12" align="center">
                <strong align="center blck" style="font-family:'Arial black';font-size:30;color:#555F6B">Popular Categories</strong><br>

            </div>
        </div>
        <form method='post' action='categories/Energy-and-Power' id="id1">
            <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 no-padding" style="margin-bottom: 10px;" onclick="document.getElementById('id1').submit();" id="cursor">

                <div class="col-md-2 col-xs-3">
                    <img src="images/icon/Energy-and-Power.jpg" class="img-rounded category-home-image" alt="Cinque Terre" width="20" height="20" style="float:left">
                </div>
                <div class="sidebar-item-inner col-md-10 col-xs-9" style="margin-top: 15px;">
                    <input type="hidden" name="id" value="1">
                    <b class="home-category-title"><a class="blck">Energy and Power</a></b>
                    <!-- <div class="item-content">
                        <span class="text-light-black" id="text-gray">Energy-and-Power expenditure over various nations as expanded all together</span>
                    </div> -->
                </div>
            </div> 
        </form>
        <form method='post' action='categories/Food-and-Beverages' id="id2">
            <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 no-padding" style="margin-bottom: 10px;" onclick="document.getElementById('id2').submit();"  id="cursor">

                <div class="col-md-2 col-xs-3">
                    <img src="images/icon/Food-and-Beverages.jpg" class="img-rounded category-home-image" alt="Cinque Terre" width="20" height="20" style="float:left">
                </div>
                <div class="sidebar-item-inner col-md-10 col-xs-9" style="margin-top: 15px;">
                    <input type="hidden" name="id" value="2">
                    <b class="home-category-title"><a class="blck"><input type='hidden' value='2' name='id'>Food and Beverages</a></b>
                    <!-- <div class="item-content">
                        <span class="text-light-black" id="text-gray">Food and Beverages Industry executive is tending to keep a tab on their business competitors. This keep them updated on strategic business activities.</span>
                    </div> -->
                </div>
            </div>
        </form>
        <form method='post' action='categories/ICT-Media' id="id3">
            <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 no-padding" style="margin-bottom: 10px;" onclick="document.getElementById('id3').submit();"  id="cursor">
                <div class="col-md-2 col-xs-3">
                    <img src="images/icon/ICT-Media.jpg" class="img-rounded category-home-image" alt="Cinque Terre" width="20" height="20" style="float:left">
                </div>
                <div class="sidebar-item-inner col-md-10 col-xs-9" style="margin-top: 15px;">
                    <input type="hidden" name="id" value="3">
                    <b class="home-category-title"><a class="blck"><input type='hidden' value='3' name='id'>ICT Media</a></b>
                    <!-- <div class="item-content">
                        <span class="text-light-black" id="text-gray">ICT Media As innovation rollout nonstop improvements crosswise over different assembling venture.</span>
                    </div> -->
                </div>
            </div>
        </form>
        <form method='post' action='categories/Machinery-and-Equipments' id="id4"> 
            <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 no-padding" style="margin-bottom: 10px;" onclick="document.getElementById('id4').submit();"  id="cursor">
                <div class="col-md-2 col-xs-3">
                    <img src="images/icon/Machinery-and-Equipments.jpg" class="img-rounded category-home-image" alt="Cinque Terre" width="20" height="20" style="float:left">
                </div>
                <div class="sidebar-item-inner col-md-10 col-xs-9" style="margin-top: 15px;">
                    <input type="hidden" name="id" value="4">
                    <b class="home-category-title"><a class="blck"><input type='hidden' value='4' name='id'>Machinery and Equipments</a></b>
                    <!-- <div class="item-content">
                        <span class="text-light-black" id="text-gray">Machinery and Equipments development and assembling areas are currently very determined by the high teeth Industry</span>
                    </div> -->
                </div>
            </div>
        </form>
        <form method='post' action='categories/Materials-and-Chemicals' id="id5"> 
            <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 no-padding" style="margin-bottom: 10px;" onclick="document.getElementById('id5').submit();"  id="cursor">
                <div class="col-md-2 col-xs-3" >
                    <img src="images/icon/Materials-and-Chemicals.jpg" class="img-rounded category-home-image" alt="Cinque Terre" width="20" height="20" style="float:left">
                </div>
                <div class="sidebar-item-inner col-md-10 col-xs-9" style="margin-top: 15px;">
                    <input type="hidden" name="id" value="5">
                    <b class="home-category-title"><a class="blck"><input type='hidden' value='5' name='id'>Materials and Chemicals</a></b>
                    <!-- <div class="item-content">
                        <span class="text-light-black" id="text-gray">Materials and Chemicals is an industry that give monetary and keeping money administrations</span>
                    </div> -->
                </div>
            </div>
        </form>
        <form method='post' action='categories/Medical-Devices</a></b>' id="id6"> 
            <div class="col-lg-4 col-md-6  col-sm-12 col-xs-12 no-padding" style="margin-bottom: 10px;" onclick="document.getElementById('id6').submit();"  id="cursor">
                <div class="col-md-2 col-xs-3">
                    <img src="images/icon/Medical-Devices.jpg" class="img-rounded category-home-image" alt="Cinque Terre" width="20" height="20" style="float:left">
                </div>
                <div class="sidebar-item-inner col-md-10 col-xs-9" style="margin-top: 15px;">
                    <input type="hidden" name="id" value="6">
                    <b class="home-category-title"><a class="blck"><input type='hidden' value='6' name='id'>Medical Devices</a></b>
                    <div class="item-content">
                        <span class="text-light-black" id="text-gray"><!-- Changing a Medical Devices habit of people and emergence of eco friendly products and creating opportunities in the consumer goods market. --></span>
                    </div>
                </div>
            </div>
        </form>
        <form method='post' action='categories/Pharmaceuticals-and-Healthcare' id="id7"> 
            <div class="col-lg-4 col-md-6  col-sm-12 col-xs-12 no-padding" onclick="document.getElementById('id7').submit();"  id="cursor">
                <div class="col-md-2 col-xs-3">
                    <img src="images/icon/Pharmaceuticals-and-Healthcare.jpg" class="img-rounded category-home-image" alt="Cinque Terre" width="20" height="20" style="float:left">
                </div>
                <div class="sidebar-item-inner col-md-10 col-xs-9" style="margin-top: 15px;">
                    <input type="hidden" name="id" value="7">
                    <b class="home-category-title"><a class="blck"><input type='hidden' value='7' name='id'>Pharmaceuticals and Healthcare</a></b>
                    <!-- <div class="item-content">
                        <span class="text-light-black" id="text-gray">Changing a Pharmaceuticals and Healthcare habits of people and emergence of eco friendly products and creating opportunities in the consumer goods market.</span>
                    </div> -->
                </div>
            </div>
        </form>
        <form method='post' action='categories/Semiconductor-and-Electronics' id="id8">
            <div class="col-lg-4 col-md-6  col-sm-12 col-xs-12 no-padding" onclick="document.getElementById('id8').submit();"  id="cursor">
                <div class="col-md-2 col-xs-3">
                    <img src="images/icon/Semiconductor-and-Electronics.jpg" class="img-rounded category-home-image" alt="Cinque Terre" width="20" height="20" style="float:left">
                </div>
                <div class="sidebar-item-inner col-md-10 col-xs-9" style="margin-top: 15px;">
                    <input type="hidden" name="id" value="8">
                    <b class="home-category-title"><a class="blck"><input type='hidden' value='8' name='id'>Semiconductor and Electronics</a></b>
                    <!-- <div class="item-content">
                        <span class="text-light-black" id="text-gray">Changing a Semiconductor and Electronics habits of people and emergence of eco friendly products and creating opportunities in the consumer goods market.</span>
                    </div> -->
                </div>
            </div>
        </form>
        <form method='post' action='categories/Consumer Goods' id="id8">
            <div class="col-lg-4 col-md-6  col-sm-12 col-xs-12 no-padding" onclick="document.getElementById('id9').submit();"  id="cursor">
                <div class="col-md-2 col-xs-3">
                    <img src="images/icon/Consumer_Goods.jpg" class="img-rounded category-home-image" alt="Cinque Terre" width="20" height="20" style="float:left">
                </div>
                <div class="sidebar-item-inner col-md-10 col-xs-9" style="margin-top: 15px;">
                    <input type="hidden" name="id" value="8">
                    <b class="home-category-title"><a class="blck"><input type='hidden' value='8' name='id'>Consumer Goods</a></b>
                    <!-- <div class="item-content">
                        <span class="text-light-black" id="text-gray">Changing a Semiconductor and Electronics habits of people and emergence of eco friendly products and creating opportunities in the consumer goods market.</span>
                    </div> -->
                </div>
            </div>
        </form> 
    </div>
</div>


<!-- <div class="main-banner2-wraper col-sm-12 col-md-12" style="" id="zero-padding">
    <div class="col-sm-6 col-md-6 no-padding" >
        <img src="images/about_us_image.jpg" class="report-home-img" id='zero-padding'/>
    </div>
    <div class="about-page-area bg-secondary section-space-bottom col-sm-6 col-md-6" style="background-color:#eee;">
        <div class="col-md-12 back-gray" align="left" style="padding: 80px;">
            <strong class="" id="new-index-title">ABOUT GARNER INSIGHTS</strong>
            <p style="border-bottom-style: solid ; width:10%; border-bottom-color:#246A9F;"></p>
            <div class="">
                <p class="" id="text-gray">We are the fulcrum between you and your market research needs. We strive to provide meticulously crafted market reports which aids decision makers with resourceful insights and structured data within the target market.   </p>
                <p id="text-gray">
                    In a nutshell, Garner Insights is a market intelligence and consulting firm with extensive experience and knowledge of the Market Research industry.
                </p>
            </div>
        </div>
        <div class="back-blue col-sm-9 float-right" style="margin-top:-70px;" >
            <p style="margin: 5px;padding:10;">By leveraging our enormous reports repository and premium strategic partnerships, we take a lot of the drudgery out of your market research hunt. Due to our domain specific expertise and strong backbone of market knowledge, we can guide you with credence and serve what is best for you!</p>
        </div>

        <div class="col-sm-10 float-center" align="center" style="margin-top:-20px; background-color: transparent; text-align: left; padding-left: 80px;margin-bottom:10px;" ><br>
            <span id="font-arial-black">OUR MISSION STATEMENT</span>
            <P class="text-light-black">Our aim is to change the dynamics of the Market Research industry by providing quality intelligence backed by data.</P>
        </div>
    </div>
</div> -->
<div class="container-fluid" style="background-color: #f4f6f8;">
    <div class="container">
        <div class="col-md-12" align="center" style="margin-top:30px; font-family:'arial';">

            <strong id="new-index-title " class="content-title">Latest Reports</strong><br><br>

            <div class="col-sm-2" id="latest-report-content" >
                <form action="{{config('app.baseURL')}}/reports" id="frm-1" method="post">
                    <a href="{{config('app.baseURL')}}/ICT%20Media/url-1">
                        <div class="latest-home-report col-sm-12">

                            <input type="hidden" value="3" name="id">
                            <img src="{{config('app.baseURL')}}/storage/app/index-category/ict.jpeg" class="click-1">
                            <center><span class="calibri">Report Name</span></center>
                        </div>
                    </a>
                </form>
            </div>


            <div class="col-sm-2" id="latest-report-content">
                <form action="{{config('app.baseURL')}}/reports" id="frm-3" method="post">
                    <a href="{{config('app.baseURL')}}/Pharmaceuticals%20and%20Healthcare/1">
                        <div class="latest-home-report col-sm-12" >

                            <input type="hidden" value="7" name="id">
                            <img src="{{config('app.baseURL')}}/storage/app/index-category/pharma.jpeg">
                            <center><span class="calibri">Global Chlorothalonil Market Research 2011- 2022</span></center>
                        </div>
                    </a>
                </form>
            </div>
            <div class="col-sm-2" id="latest-report-content">
                <form action="{{config('app.baseURL')}}/reports" id="frm-4" method="post">
                    <a href="">
                        <div class="latest-home-report col-sm-12">

                            <input type="hidden" value="4" name="id">
                            <img src="{{config('app.baseURL')}}/storage/app/index-category/machine.jpeg">
                            <center><span class="calibri">Global Machine Research 2011- 2022</span></center>
                        </div>
                    </a>
                </form>
            </div>
            <div class="col-sm-2" id="latest-report-content">
                <form action="{{config('app.baseURL')}}/reports" id="frm-5" method="post">
                    <a href="">
                        <div class="latest-home-report col-sm-12" onclick="document.getElementById('frm-5').submit();">

                            <input type="hidden" value="8" name="id">
                            <img src="{{config('app.baseURL')}}/storage/app/index-category/semicon.jpeg">
                            <center><span class="calibri">Semi Conductor</span></center>
                        </div>
                    </a>
                </form>
            </div>
            <div class="col-sm-2" id="latest-report-content">
                <form action="{{config('app.baseURL')}}/reports" id="frm-5" method="post">
                    <a href="">
                        <div class="latest-home-report col-sm-12" onclick="document.getElementById('frm-5').submit();">

                            <input type="hidden" value="8" name="id">
                            <img src="{{config('app.baseURL')}}/storage/app/index-category/matterial.jpeg">
                            <center><span class="calibri">Matterials</span></center>
                        </div>
                    </a>
                </form>
            </div>
            <div class="col-sm-2" id="latest-report-content">
                <form action="{{config('app.baseURL')}}/reports" id="frm-5" method="post">
                    <a href="">
                        <div class="latest-home-report col-sm-12" onclick="document.getElementById('frm-5').submit();">

                            <input type="hidden" value="8" name="id">
                            <img src="{{config('app.baseURL')}}/storage/app/index-category/medical.jpeg">
                            <center><span class="calibri">Medicals</span></center>
                        </div>
                    </a>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="trending-products-area" style="margin-top: 40px;">                
    <div class="container">
        <h2 class="title-default col-sm-12 content-title" >View Our Clients</h2>  
    </div>
    <div class="container" style="" id="client-footer">
        <div class="row">
            <div class="fox-carousel nav-control-middle margin-left-right" data-loop="true" data-items="4" data-margin="0" data-autoplay="true" data-autoplay-timeout="100" data-smart-speed="2000" data-dots="false" data-nav="true" data-nav-speed="false" data-r-x-small="1" data-r-x-small-nav="true" data-r-x-small-dots="false" data-r-x-medium="2" data-r-x-medium-nav="true" data-r-x-medium-dots="false" data-r-small="2" data-r-small-nav="true" data-r-small-dots="false" data-r-medium="3" data-r-medium-nav="true" data-r-medium-dots="false" data-r-large="6" data-r-large-nav="true" data-r-large-dots="false">
                <div class="single-item-grid">
                    <div class="item-img">
                        <img src="{{config('app.baseURL')}}/img/product/3M01-3M-LOGO.jpg" alt="product" class="img-responsive">
                    </div>                            
                </div>
                <div class="single-item-grid">
                    <div class="item-img">
                        <img src="{{config('app.baseURL')}}\img\product\Arthur D. Little.jpg" alt="product" class="img-responsive">
                    </div>                            
                </div>
                <div class="single-item-grid">
                    <div class="item-img">
                        <img src="{{config('app.baseURL')}}\img\product\Caterpillar.jpg" alt="product" class="img-responsive">
                    </div>                            
                </div>
                <div class="single-item-grid">
                    <div class="item-img">
                        <img src="{{config('app.baseURL')}}\img\product\DuPont.jpg" alt="product" class="img-responsive">
                    </div>                            
                </div>
                <div class="single-item-grid">
                    <div class="item-img">
                        <img src="{{config('app.baseURL')}}\img\product\H Energy.png" alt="product" class="img-responsive">
                    </div>                            
                </div>
                <div class="single-item-grid">
                    <div class="item-img">
                        <img src="{{config('app.baseURL')}}\img\product\hp.jpg" alt="product" class="img-responsive">
                    </div>                            
                </div>
                <div class="single-item-grid">
                    <div class="item-img">
                        <img src="{{config('app.baseURL')}}\img\product\International Paper.jpg" alt="product" class="img-responsive">
                    </div>                            
                </div>
                <div class="single-item-grid">
                    <div class="item-img">
                        <img src="{{config('app.baseURL')}}\img\product\Lincoln University.png" alt="product" class="img-responsive">
                    </div>                            
                </div>
                <div class="single-item-grid">
                    <div class="item-img">
                        <img src="{{config('app.baseURL')}}\img\product\Marshall Aerospace & Defence Group.png" alt="product" class="img-responsive">
                    </div>                            
                </div>
                <div class="single-item-grid">
                    <div class="item-img">
                        <img src="{{config('app.baseURL')}}\img\product\Meadow_Foods.jpg" alt="product" class="img-responsive">
                    </div>                            
                </div>
                <div class="single-item-grid">
                    <div class="item-img">
                        <img src="{{config('app.baseURL')}}\img\product\meadow-foods.png" alt="product" class="img-responsive">
                    </div>                            
                </div>
                <div class="single-item-grid">
                    <div class="item-img">
                        <img src="{{config('app.baseURL')}}\img\product\THE BOSTON.png" alt="product" class="img-responsive">
                    </div>                            
                </div>
                <div class="single-item-grid">
                    <div class="item-img">
                        <img src="{{config('app.baseURL')}}\img\product\Old-World-Industries-LLC_logo.jpg" alt="product" class="img-responsive">
                    </div>                            
                </div>
            </div>
        </div>
    </div>
</div>
<!-- 
    <div class="product-page-list bg-secondary section-space-bottom" style="">
        <div class="col-md-12" align="center" style="margin-top:50px; font-family:'arial'">
            <span style="color:#aaa">WHAT PEOPLE SAY</span><br>
            <h2 class="title-default col-sm-12 content-title">TESTIMONIALS</h2><br>
            <img src="images/design.png"><br><br>

            <div class="container">
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="item active">
                            <div class="col-sm-5 margin-1" id="index-padding1">
                                <i class="fa fa-quote-left" aria-hidden="true" id="testimonial-color"></i><center>
                                <div style="min-height: 150px;" id="text-gray-dark">What amazed me most was the professionalism and client satisfaction provided by Reports Monitor. Their responses were quick and actioned on immediately.</div>

                                <div class="author-name" >
                                    <br> 
                                    <span align="left" class="author-pos"><b>Sr. Manager</b></span><br>
                                    <span align="left" class="author-pos">A UK based manufacturing firm</span>
                                </div>
                            </center>
                        </div>                       
                        <div class="col-sm-5 margin-2" id="index-padding1">
                            <i class="fa fa-quote-left" aria-hidden="true" id="testimonial-color"></i><center>
                            <div id="text-gray-dark" style="min-height: 150px;">I would like to thank the team at Reports Monitor, you guys made my job so easier with your spoon fed service and quality market study.</div>

                            <div class="author-name" style="background-color: #379F9E;"><br> 

                                <span align="left" class="author-pos"><b>President </b></span><br>
                                <span align="left" class="author-pos">At a US based consulting firm</span>
                            </div>
                        </center>
                    </div>                       
                </div>
                <div class="item">
                    <div class="col-sm-5 margin-1" id="index-padding1">
                        <i class="fa fa-quote-left" aria-hidden="true" id="testimonial-color"></i><center>
                        <div id="text-gray-dark" style="min-height: 150px;">The team of Reports Monitor solved my queries in a timely fashion and gracefully. I have purchased reports from them a few times now and they never cease to impress with their highly intellectual team.</div>

                        <div class="author-name"><br> 
                            <span align="left" class="author-pos"><b>Marketing Manager </b></span><br>
                            <span align="left" class="author-pos">At a Fortune 100 pharmaceutical firm</span>
                        </div>
                    </center>
                </div>
                <div class="col-sm-5 margin-2" id="index-padding1">
                    <i class="fa fa-quote-left" aria-hidden="true" id="testimonial-color"></i><center>
                    <div id="text-gray-dark" style="min-height: 150px;" >I had some issues with the payment gateway and almost the immediate second I get a call from one of the enthusiastic sales member who guided me throughout the process and also reassured me of the next steps.</div>

                    <div class="author-name"><br> 
                        <span align="left" class="author-pos"><b>A Consultant </b></span><br>
                        <span align="left" class="author-pos">At a German based retail firm</span></div>
                    </center>
                </div>
            </div>
            <div class="item">
                <div class="col-sm-5 margin-1" id="index-padding1">
                    <i class="fa fa-quote-left" aria-hidden="true" id="testimonial-color"></i><center>
                    <div id="text-gray-dark" style="min-height: 150px;">The quality of data encompassed in the report was very useful for me in my marketing strategy needs</div>

                    <div class="author-name"><br> 
                        <span align="left" class="author-pos"><b>Director of Marketing</b></span><br>
                        <span align="left" class="author-pos">At a US based Manufacturing firm</span></div>
                    </center>
                </div>
                <div class="col-sm-5 margin-2" id="index-padding1">
                    <i class="fa fa-quote-left" aria-hidden="true" id="testimonial-color"></i>
                    <div id="text-gray-dark" style="min-height: 150px;">I like the way they operate in terms of their reassuring emails and timely phone calls to keep me posted. I think this is what made me really happy as a customer. I would highly recommend them to all</div>
                    <center>
                        <div class="author-name"><br> 
                            <span align="left" class="author-pos"><b>Senior Engineer </b></span><br>
                            <span align="left" class="author-pos">At a Fortune 500 IT firm</span></div>
                        </center>
                    </div>
                </div>
            </div>

           
            <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left"></span>
                <span class="sr-only" style="color:red">Previous</span>
            </a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next" id="color-12">
                <span class="glyphicon glyphicon-chevron-right"></span>
                <span class="sr-only">Next</span>
            </a>
            <div class="col-lg-12" style="margin-top:100px;">
                <ol class="carousel slide carousel-indicators">
                    <li data-target="#myCarousel " data-slide-to="0" class="active" id="slide-color"></li>
                    <li data-target="#myCarousel" data-slide-to="1" id="slide-color"></li>
                    <li data-target="#myCarousel" data-slide-to="2" id="slide-color"></li>
                </ol>
            </div>
        </div>
    </div>
</div>
</div> -->
<div class="trending-products-area section-space-default">
    <div class="container"></div></div>

    @endsection
