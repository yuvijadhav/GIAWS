@extends('layouts.app')
<style type="text/css">
	div a{
		color: #000;
	}
</style>
@section('content')
@include('public.top-search')
<title>Latest Reports - Garner Insights</title>
<div class="pagination-area bg-secondary col-md-12" style="background-color: #eee">
	<div class="container">
		<div class="pagination-wrapper" style="padding: 15px 0 15px;">
			<ul>
				<li><a href="{{Config('app.baseURL')}}">Home</a><span> -</span></li>
				<li>Latest Blog</li>
			</ul>
		</div>
	</div>  
</div>
<meta name="keywords" content="Latest News">		

<div class="container" >	
	<table class="table" id="articles">
	</table>
	
</div>

<script type="text/javascript">
	var articles=<?php echo json_encode($articles);?>;
	var ul=$("#articles");
	$.each(articles,function(intex,item) {

		

		var li="<tr><td><a href='{{config('app.baseURL')}}/articleDetails?id="+item.article_id+"'>{{config('app.baseURL')}}/article/"+item.article_title+"</a></td></tr>";
		ul.append(li);
	});
</script>

@endsection
