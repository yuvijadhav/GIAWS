<div class="sidebar-item">
    <div class="sidebar-item-inner">
        <h3 class="sidebar-item-title">Latest Reports</h3>                
        <div class="sidebar-single-item-grid" id="report-sidebar">
            
        </div>       
        <center><a href="reports"><button type="button" class="btn btn-primary">View More</button></a></center>
    </div>
</div>
<div class="sidebar-item">
    <div class="sidebar-item-inner">
        <h3 class="sidebar-item-title">Latest News</h3>                
        <div class="sidebar-single-item-grid" id="news-sidebar">
            
        </div>
        <center><a href="news"><button type="button" class="btn btn-primary">View More</a></button></center>
    </div>
</div>
