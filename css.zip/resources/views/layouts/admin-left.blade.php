<div class="fox-sidebar">
    <div class="sidebar-item">
        <div class="sidebar-item-inner">
            <h3 class="sidebar-item-title">Admin</h3>
            <ul class="sidebar-categories-list">
                <!-- <li><a href="allCategories">Categories<span>(150)</span></a></li> -->
                <li><a href="allCategories">Categories</a></li>
                
                <li><a href="allPublishers">Publishers</a></li>
                <li><a href="allReports">Reports</a></li>
                <li><a href="allPressReleases">Press Releases</a></li>
                <li><a href="allBlogs">Blogs</a></li>
                <li><a href="allRegions">Regions</a></li>
            </ul>
        </div>
    </div>
</div>