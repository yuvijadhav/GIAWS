<div class="fox-sidebar">
    
    <div class="sidebar-item">
        <div class="sidebar-item-inner">
            <h3 class="sidebar-item-title">Latest Reports</h3>
            <div id="latest-news">
                <div class="sidebar-single-item-grid">
                    <div class="item-content">
                        <div class="item-info">
                            <h3><a href="#">Maruti Suzuki is ready</a></h3>
                            <p>Maruti Suzuki is ready to launch Vitara Brezza! Maruti Suzuki's.</p>
                        </div>
                        <div class="item-info">
                            <h3><a href="#">Maruti Suzuki is ready</a></h3>
                            <p>Maruti Suzuki is ready to launch Vitara Brezza! Maruti Suzuki's.</p>
                        </div>
                        <div class="item-info">
                            <h3><a href="#">Maruti Suzuki is ready</a></h3>
                            <p>Maruti Suzuki is ready to launch Vitara Brezza! Maruti Suzuki's.</p>
                        </div>
                        <div class="item-info">
                            <h3><a href="#">Maruti Suzuki is ready</a></h3>
                            <p>Maruti Suzuki is ready to launch Vitara Brezza! Maruti Suzuki's.</p>
                        </div>
                        <div class="item-info">
                            <h3><a href="#">Maruti Suzuki is ready</a></h3>
                            <p>Maruti Suzuki is ready to launch Vitara Brezza! Maruti Suzuki's.</p>
                        </div>                        
                    </div>
                </div>
            </div>
            <center><button type="button" class="btn btn-primary">View More</button></center>
        </div>
    </div>
</div>