<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Report;
use App\SubCategory;
use App\Publisher;	
use Illuminate\Support\Facades\Input;
use Excel;
use App\Region;
use Softon\Indipay\Facades\Indipay;  

class ReportController extends Controller
{


    public  function getAxisPayReturn(Request $request){
        $post=$request->all();
        print_r($post);
        return view('payment.pay-return');
    }
    public function getAddReport(Request $request){
        $report = Report::all();
        $sub_category = SubCategory::all();
        $publisher = Publisher::all();
        $region = Region::all();
        return view('report.addReport')->with('report',$report)->with('sub_category',$sub_category)->with('publisher',$publisher)->with('region',$region);
    }

    public function postAddReport(Request $request){
        $post = $request->all();
        $this->validate($request,Report::$reportRule);
        $report = new Report();
        $report->report_title=$post['report_title'];
        $report->sub_category_id=$post['sub_category_id'];
        $report->publisher_id=$post['publisher_id'];
        $report->region_id=$post['region_id'];
        $report->report_date=$post['report_date'];
        $report->report_pages=$post['report_pages'];
        $report->long_description=$post['long_description'];
        $report->long_content=$post['long_content'];
        $report->table_figures=$post['table_figures'];

        $url=$post['url'];

        if($url==""){
            $url=str_replace(" ","-",$post['report_title']);
            $url=str_replace("(", "", $url);
            $url=str_replace(")", "", $url);
            $url=str_replace("$", "", $url);
            $url=str_replace("&", "", $url);
        }
        $report->url=$url;

        if(isset($post['status'])){
            $report->status=1;
        }
        else{
            $report->status=0;
        }
        $report->single_price=$post['single_price'];
        $report->corporate_price=$post['corporate_price'];
        $report->enterprise_price=$post['enterprise_price'];
        $report->meta_title=$post['meta_title'];
        $report->meta_keywords=$post['meta_keywords'];
        $report->meta_description=$post['meta_description'];
        $report->save();
        flash('Report has been added successfully','success')->important();
        return redirect('allReports');
    }

    public function getAllReports(Request $request){
        $data = Report::with('subCategory');
        $search="";
        if(isset($request->search)){
            $search=$request->search;
            $data = $data->where('report_title', 'like', "%".$search."%");
        }
        $total_count = Report::where('status','1')->count();
        $data=$data->take(10)->orderBy('report_id','desc')->get();
        return view('report.allReports')->with('data',$data)->with('total_count',$total_count)->with('search',$search);
    }

//Ajax
    public function getAllReportData(Request $request){
        $post = $request->all();
        $search=$post['search'];
        $page = $post['active_page'];
        $limit = $post['limit'];

        $data = Report::where('status','1');
        if($search!=""){
            $data = $data->where('report_title', 'like', "%".$search."%");
        }
        $total_count = $data->count();
        $data=$data->skip(($page-1)*$limit)->take($limit)->orderBy('report_id','desc')->get();
        $data=array("total_count"=>$total_count,"data"=>$data);
        return $data;
    }

    public function getEditReport(Request $request){
        if(isset($_GET['id'])){
            $report_id=$_GET['id'];
            $report=Report::find($report_id);
            $sub_category = SubCategory::all();
            $publisher = Publisher::all();
            $region = Region::all();
            return view('report.editReport')->with('report',$report)->with('sub_category',$sub_category)->with('publisher',$publisher)->with('region',$region);
        }
        return redirect('allReports');
    }

    public function postEditReport(Request $request){
        $post = $request->all();
        $report_id = $post['report_id'];
        if($report_id){
            $report = Report::find($report_id);
            $this->validate($request,Report::$editRule);

            $this->validate($request,['report_title'=>'unique:reports,report_title,'.$report_id.',report_id']);

            $report->report_title=$post['report_title'];
            $report->sub_category_id=$post['sub_category_id'];
            $report->publisher_id=$post['publisher_id'];
            $report->region_id=$post['region_id'];
            $report->report_date=$post['report_date'];
            $report->report_pages=$post['report_pages'];
            $report->long_description=$post['long_description'];
            $report->long_content=$post['long_content'];
            $report->table_figures=$post['table_figures'];
            $report->url=$post['url'];
            if(isset($post['status'])){
                $report->status=1;
            }
            else{
                $report->status=0;
            }
            $report->single_price=$post['single_price'];
            $report->corporate_price=$post['corporate_price'];
            $report->enterprise_price=$post['enterprise_price'];
            $report->meta_title=$post['meta_title'];
            $report->meta_keywords=$post['meta_keywords'];
            $report->meta_description=$post['meta_description'];
            $report->save();
            flash('Report Updated Successfully...', 'success');
        }
        return redirect('allReports');
    }

    public function getDeleteReport(Request $request){
        if(isset($_GET['id'])){
            $report_id=$_GET['id'];
            $report = Report::find($report_id);
            $report->delete();
            flash('Report has been deleted successfully...','danger')->important();
        }
        return redirect('allReports');
    }

    public function getUploadFile(){        
        return view('report.uploadFile');
    }

    public function postUploadFile(Request $request){
        $this->validate($request,["upload_file"=>'required|mimes:xls']);
        $file = Input::file('upload_file');
        Excel::load($file, function($reader) {
            $sheet=$reader->all();
            
            // foreach ($sheets as $sheet) {
            //$sheet=$sheets[0];
            // print_r($sheet['published_date']); die;
            foreach ($sheet as $row){

                $report_title=$row->title;

                $exist=Report::where('report_title',$report_title)->first();

                if($exist==""){
                    $published_dates=explode(" ", $row->published_date);
                    $published_date=$published_dates[0];
                    $report=new Report();

                    $url=str_replace(" ","-",$row->title);
                    $url=str_replace("(", "", $url);
                    $url=str_replace(")", "", $url);
                    $url=str_replace("$", "", $url);
                    $url=str_replace("&", "", $url);
                    $url = preg_replace('#\s+#',',',trim($url));
                    $report->url=$url;
                    if($row->is_active==1){
                        $report->status=1;
                    }else{
                        $report->status=0;
                    }
                    $report->sub_category_id=$row->category_id;
                    $report->publisher_id=$row->publisher_id;
                    $report->report_title=$row->title;
                    $report->long_description=$row->long_description;
                    $report->long_content=$row->content;
                    $report->report_pages=$row->number_of_pages;
                    $report->region_id=$row->region_id;
                    $report->table_figures=$row->table_figures;
                    $report->report_date=$row->published_date;
                    $report->single_price=$row->single_user_price;
                    $report->corporate_price=$row->multi_user_price;
                    $report->enterprise_price=$row->enterprise_user_price;
                    $report->meta_title=$row->meta_title;
                    $report->meta_description=$row->meta_description;
                    $report->meta_keywords=$row->meta_keywords;
                    $report->save();
                }
                else{
                    flash($report_title,"danger");
                }
            }
        });
        return redirect('allReports');
    }

    public function postPayment(Request $request){
        $sub_categories=SubCategory::all();
        $post=$request->all();
        $report_id=$post['report_id'];
        $report=Report::find($report_id);
        $type=$post['type'];
        $amount=$post['amount'];

// if($payment_way==1){

        return view('public.payment')->with('report',$report)->with('type',$type)->with('amount',$amount)->with('sub_categories',$sub_categories);
// }
// if($payment_way==2){

//     return view('public.ebs1')->with('report',$report)->with('type',$type)->with('amount',$amount);
// }


// if($payment_way==2){ 
//  $parameters = [

//     'tid' => '1233221223322',

//     'order_id' => '1232212',

//     'amount' => $post['amount'],

//     'report_id' => $post['report_id']

//     ];

//     $order = Indipay::gateway('EBS')->prepare($parameters);
//     return Indipay::process($order);
// }
    }
    public function paymentGateway(Request $request){
        $post=$request->all();
        $report_id=$post['report_id'];
        $report=Report::find($report_id);
        $type=$post['type'];

        $amount=$post['amount'];
        $payment_way=$post['payment_way'];

        $first_name=$request->first_name;
        $email=$request->email;
        $designation=$request->designation;
        $address=$request->address;
        $zip=$request->zip;
        $last_name=$request->last_name;
        $phone_no=$request->phone_no;
        $company=$request->company;
        $city=$request->city;
        $state=$request->state;
        $country=$request->country;
        $ip= $request->getClientIp();
        $url=$report->url;
        $report_title=$report->report_title;
        $pre=$request->pre;


        if($payment_way==1){

        $object=array('first_name'=>$first_name,'email'=>$email,'designation'=>$designation,'address'=>$address,'zip'=>$zip,'last_name'=>$last_name,'phone_no'=>$phone_no,'company'=>$company,'city'=>$city,'source'=>'Papal','state'=>$state,'country'=>$country,'ip'=>$ip,'url'=>$url,'report_id'=>$report_id,'report_title'=>$report_title,'amount'=>$amount,'pre'=>$pre);  

        $this->sendHtmlMail4($object);

        return view('public.checkout')->with('report',$report)->with('type',$type)->with('amount',$amount)->with('post',$post);
        }
        if($payment_way==2){

            $object=array('first_name'=>$first_name,'email'=>$email,'designation'=>$designation,'address'=>$address,'zip'=>$zip,'last_name'=>$last_name,'phone_no'=>$phone_no,'company'=>$company,'city'=>$city,'source'=>'Wire-Transfer','state'=>$state,'country'=>$country,'ip'=>$ip,'url'=>$url,'report_id'=>$report_id,'report_title'=>$report_title,'amount'=>$amount,'pre'=>$pre);

            $this->sendHtmlMail4($object);
            $report=Report::with('subCategory')->orderBy('created_at','desc')->take(10)->get();
            return view('public.wireThankYou')->with('report_title',$report_title)->with('report',$report);
        }
    }

    public function getThankyou(Request $request){
        $report=Report::with('subCategory')->orderBy('created_at','desc')->take(10)->get();     
        return view('public.thankYou')->with('report',$report);
    }
}
