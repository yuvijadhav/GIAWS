<?php

namespace App\Http\Controllers;

use Symfony\Component\HttpFoundation\Request;
use App\Article;
use App\News;
use App\Report;
use App\Category;
use App\SubCategory;
use App\Publisher;
use App\Newsletter;
use App\Region;
use App\EnquiryReport;
use Weboap\Visitor\Visitor;


class PublicController extends Controller{


    public function getebs(){
        $sub_categories=SubCategory::all();
        return view('public.ebs1')->with('sub_categories',$sub_categories);
    }

    public function postebs(){
        $sub_categories=SubCategory::all();
        return view('public.ebs2')->with('$sub_categories',$sub_categories);
    }

    public function checkout(){
        $sub_categories=SubCategory::all();
        return view('public.checkout')->with('sub_categories',$sub_categories);
    }

    public function checkoutEBS(){
        $sub_categories=SubCategory::all();
        return view('public.checkoutEBS')->with('sub_categories',$sub_categories);
    }
    
    public function getHome(){
        $sub_categories=SubCategory::all();
        return view("public.index")->with('sub_categories',$sub_categories);
    }
    public function getAboutus(){
        $sub_categories=SubCategory::all();
        return view("public.index")->with('sub_categories',$sub_categories);
    }
    public function getFaq(){
        $sub_categories=SubCategory::all();
        return view("faq")->with('sub_categories',$sub_categories);	
    }
    public function getContact(){
        $sub_categories=SubCategory::all();
        return view("contact")->with('sub_categories',$sub_categories);
    }

    public function postContact(Request $request){
        $ip= $request->getClientIp();
        $name=$request->name;
        $email=$request->email;
        $mobile=$request->mobile;
        $city=$request->city;
        $subject=$request->subject;
        $message=$request->message;
        $object=array('name'=>$name,'email'=>$email,'mobile'=>$mobile,'city'=>$city,'subject'=>$subject,'text'=>$message,'filename'=>'contact','ip'=>$ip);
        $this->sendHtmlMail2($object);
        return redirect('thank-you');
    }

    public function postQuote(Request $request){
        $ip= $request->getClientIp();
        $name=$request->name;
        $email=$request->email;
        $mobile=$request->mobile;
        $message=$request->message;
        $object=array('name'=>$name,'email'=>$email,'mobile'=>$mobile,'text'=>$message,'filename'=>'quote','ip'=>$ip);
        $this->sendHtmlMail3($object);
        return redirect('thank-you');
    }

    public function getabout(){
        $sub_categories=SubCategory::all();
        return view("about-us")->with('sub_categories',$sub_categories);
    }

    public function getTermsAndCondition(){
        $sub_categories=SubCategory::all();
        return view("terms-and-condition")->with('sub_categories',$sub_categories);
    }

    public function getReturnPolicy(){
        $sub_categories=SubCategory::all();
        return view("return-policy")->with('sub_categories',$sub_categories);
    }

    public function getPrivacyPolicy(){
        $sub_categories=SubCategory::all();
        return view("privacy-policy")->with('sub_categories',$sub_categories);
    }

    public function getDisclaimer(){
        $sub_categories=SubCategory::all();
        return view("disclaimer")->with('sub_categories',$sub_categories);
    }

    public function getHowtoOrder(){
        $sub_categories=SubCategory::all();
        return view("how-to-order")->with('sub_categories',$sub_categories);
    }

    public function getDelivery(){
        $sub_categories=SubCategory::all();
        return view("delivery")->with('sub_categories',$sub_categories);
    }

    public function getSitemap(){
        $sub_categories=SubCategory::all();
        return view("sitemap")->with('sub_categories',$sub_categories);
    }

    public function getcheckout(){
        $sub_categories=SubCategory::all();
        return view('public.checkout')->with('sub_categories',$sub_categories);
    }

    public function getPaymentMethods(Request $request){
        $sub_categories=SubCategory::all();
        return view('public.payment-methods')->with('sub_categories',$sub_categories);
    }

    public function getServices(){
        $sub_categories=SubCategory::all();
        $report=Report::where('status','1')->with('subCategory')->take(5)->get();
        return view("public.services")->with('report',$report)->with('search','')->with('sub_categories',$sub_categories);
    }

    public function postNewsletter(Request $request){
        $sub_categories=SubCategory::all();
        $post = $request->all();
        $this->validate($request,['email'=>'required']);
        $newsletter = new Newsletter();
        $newsletter->email=$post['email'];
        $newsletter->save();
        flash('subscribed successfully','success')->important();
        return view('public.index')->with('sub_categories',$sub_categories);
    }

    public function getArticles(Request $request){
        $sub_categories=SubCategory::all();
        $data = Article::take(10)->orderBy('created_at','desc')->get();
        $total_count = Article::count();
        $report=Report::where('status',1)->with("subCategory")->take(10)->get();
        return view('public.pressRelease')->with('data',$data)->with('total_count', $total_count)->with("report",$report)->with('search','')->with('sub_categories',$sub_categories);
    }

    public function getArticlesData(Request $request){
        $post = $request->all();

        $page = $post['active_page'];
        $limit = $post['limit'];
        $total_count = Article::count();
        $data = Article::skip(($page-1)*$limit)->take($limit)->get();
        $data=array("total_count"=>$total_count,"data"=>$data);
        return $data;
    }

    public function getNews(Request $request){
        $sub_categories=SubCategory::all();
        $data=News::take(10)->get();
        $total_count=News::count();      
        $report=Report::where('status',1)->with('subCategory')->take(10)->get();
        return view('public.blogs')->with('data', $data)->with('total_count',$total_count)->with("report",$report)->with('search','')->with('sub_categories',$sub_categories);
    }

    //ajax
    public function getNewsData(Request $request){
        $post=$request->all();
        $page=$post['active_page'];
        $limit=$post['limit'];
        $total_count=News::count();
        $data=News::skip(($page-1)*$limit)->take($limit)->get();
        $data=array("total_count"=>$total_count,"data"=>$data);
        return $data;
    }

    public function getReports(Request $request){
        $sub_categories=SubCategory::all();
        $data = Report::where('status',1)->take(10)->with('subCategory')->with('region')->get();
        $categories=SubCategory::all();
        $regions=Region::all();

        $total_count = Report::where('status',1)->count();
        return view('public.reports')->with('data',$data)->with("categories",$categories)->with("regions",$regions)->with('total_count',$total_count)->with("sub_category_id","0")->with("search","")->with('sub_categories',$sub_categories);
    }

    //Ajax
    public function getReportsData(Request $request){
        $sub_categories=SubCategory::all();
        $post = $request->all();
        $page = $post['active_page'];
        $limit = $post['limit'];
        $categories=$request->categories;
        $regions=$request->regions;
        $search=$request->search;
        $reports=Report::where('status',1);
        if($categories!=""){
            $reports=$reports->whereIn("sub_category_id",$categories);
        }
        if($regions!=""){
            $reports=$reports->whereIn("region_id",$regions);
        }
        if($search!=""){
            $reports=$reports->where('report_title', 'like', "%".$search."%"); 
        }
        $total_count = $reports->count();
        $reports=$reports->with('subCategory')->with('region')->skip(($page-1)*$limit)->take($limit)->get();
        $data=array("total_count"=>$total_count,"data"=>$reports,"sub_categories"=>$sub_categories);
        return $data;
    }

    public function getCategories(Request $request){
        $sub_categories=SubCategory::all();
        $data=SubCategory::all();
        $total_count=SubCategory::count(); 
        $report=Report::where('status',1)->with('subCategory')->take(5)->get();       
        return view('public.category')->with('data', $data)->with('total_count',$total_count)->with('report',$report)->with('search','')->with('sub_categories',$sub_categories);
    }

    //ajax
    public function getCategoryData(Request $request){
        $post=$request->all();
        $page=$post['active_page'];
        $limit=$post['limit'];
        $total_count=SubCategory::count();
        $data=SubCategory::skip(($page-1)*$limit)->take($limit)->get();
        $data=array("total_count"=>$total_count,"data"=>$data);
        return $data;
    }

    public function postAddEnquiryReport(Request $request){
        $this->validate($request,EnquiryReport::$rules);
        $ip= $request->getClientIp();
        $post=$request->all();
        $report_id=$post['report_id'];
        $url=$post['url'];
        $enquiry_report= new EnquiryReport();
        $enquiry_report->enquiry_name=$post['enquiry_name'];
        $enquiry_report->enquiry_email=$post['enquiry_email'];
        $enquiry_report->enquiry_phone=$post['enquiry_phone'];
        $enquiry_report->enquiry_company=$post['enquiry_company'];
        $enquiry_report->enquiry_title=$post['enquiry_title'];
        $enquiry_report->enquiry_country=$post['enquiry_country'];
        $enquiry_report->save();
        $enquiry_source=$post['source'];
        $enquiry_title=$post['report_id'];
        $enquiry_description=$post['category_description'];

        $object=array('name'=>$post['enquiry_name'],'email'=>$post['enquiry_email'],'mobile'=>$post['enquiry_phone'],'designation'=>$post['enquiry_title'],'enquiry_company'=>$post['enquiry_company'],'country'=>$post['enquiry_country'],'description'=>$enquiry_description,'report_pages'=>$post['report_pages'],'report_title'=>$post['report_id'],'source'=>$enquiry_source,'ip'=>$ip,'url'=>$url);
        $this->sendHtmlMail($object);
        //flash('Enqury sent successfully','success')->important();
        return redirect('thank-you');
    }

    public function postAddEnquiry(Request $request){
        $this->validate($request,EnquiryReport::$rules1);
        $post=$request->all();
        $ip= $request->getClientIp();
        $url=$post['url'];
        $object=array('name'=>$post['name'],'email'=>$post['email'],'mobile'=>$post['phone'],'source'=>'enquiry before buying','report'=>$post['report_id'],'ip'=>$ip,'report_url'=>$url);
        $this->sendHtmlMail1($object);
        //flash('Enqury sent successfully','success')->important();
        return redirect('thank-you');
    }

    public function getReportDetails($url){
        $sub_categories=SubCategory::all();
        if($url!="null"){
            $report=Report::where('status',1)->where("url",$url)->with("publisher")->with("subCategory")->with("region")->first();
            $relatedReports=Report::where('status',1)->where("sub_category_id",$report->sub_category_id)->where("report_id","!=",$report->report_id)->with("publisher")->with("subCategory")->take(5)->get();
            return view('report.reportDetails')->with('report',$report)->with('relatedReports',$relatedReports)->with('sub_categories',$sub_categories);
        }else{
           return redirect('reports');
       }
   }

   public function getNewsDetails(Request $request){
    $sub_categories=SubCategory::all();
    $news_id=$request->url;
    $news=News::where("news_url",$news_id)->first();
    $report=Report::where('status',1)->take(10)->get();
    $relatedNews=News::where("news_id","!=",$news->news_id)->take(5)->get();    
    return view('news.blogDetails')->with('news',$news)->with('relatedNews',$relatedNews)->with('report',$report)->with('search','')->with('sub_categories',$sub_categories);
}

public function getArticleDetails(Request $request){
    $sub_categories=SubCategory::all();

    $article_id=$request->url;
    $article=Article::where("article_url",$article_id)->first();
    $relatedArticle=Article::where("article_id","!=",$article->article_id)->take(5)->get();
    $report=Report::where('status',1)->with("subCategory")->take(10)->get();    
    return view('article.pressReleaseDetails')->with('article',$article)->with('relatedArticle',$relatedArticle)->with('report',$report)->with('search','')->with('sub_categories',$sub_categories);
}

public function getCategoryDetails(Request $request){
    $sub_categories=SubCategory::all();
    $sub_category_id=$_GET['id'];
    $sub_category=SubCategory::where("sub_category_id",$sub_category_id)->first();
    $relatedCategory=SubCategory::where("sub_category_id","!=",$sub_category->sub_category_id)->take(10)->get();  
    $report=Report::where('status',1)->take(10)->get();  
    return view('public.categoryDetails')->with('sub_category',$sub_category)->with('relatedCategory',$relatedCategory)->with('report',$report)->with('sub_categories',$sub_categories);
}

public function getFormatnDelivery(Request $request){
    $sub_categories=SubCategory::all();
    return view('formatsndelivery')->with('sub_categories',$sub_categories);
}

public function postReports(Request $request){
    $sub_categories=SubCategory::all();
    $sub_category_id = $request->id;
    $search=$request->search;

    $reports = Report::where('status',1)->with('subCategory')->with('region');
    if(isset($search)){
        $reports=$reports->where('report_title', 'like', "%".$search."%");
    }

    if(isset($sub_category_id)){
        $reports=$reports->where('sub_category_id',$sub_category_id);
    }
    else{
        $sub_category_id=0;
    }
    $total_count = $reports->count();
    $reports=$reports->take(10)->get();

    $categories=SubCategory::all();
    $regions=Region::all();


    return view('public.reports')->with('sub_category_id',$sub_category_id)->with('data',$reports)->with('categories',$categories)->with('regions',$regions)->with('total_count',$total_count)->with('search', $search)->with('sub_categories',$sub_categories);
}

public function getCategory($url){
    $category=SubCategory::where('sub_category_description',$url)->first();
    if($category!=""){
        $sub_categories=SubCategory::all();
        $sub_category_id = $category->sub_category_id;
        $search="";
        $reports = Report::where('status',1)->with('subCategory')->with('region');
        $reports=$reports->where('sub_category_id',$sub_category_id);
        $total_count = $reports->count();
        $reports=$reports->take(10)->get();

        $categories=SubCategory::all();
        $regions=Region::all();


        return view('public.reports')->with('sub_category_id',$sub_category_id)->with('data',$reports)->with('categories',$categories)->with('regions',$regions)->with('total_count',$total_count)->with('search', $search)->with('sub_categories',$sub_categories);
    }else{
        return redirect('reports');
    }
}

public function getHeader(Request $request){
    return view('layouts.header');
}

public function getCategorMenu(Request $request){
    $sub_categories=SubCategory::all();
    return $sub_categories;
}

public function getPaymentSuccess(Request $request){
    $sub_categories=SubCategory::all();
    return view('mail.paymentSuccess')->with('sub_categories',$sub_categories);
}

public function postPaymentSuccess(Request $request){
    $sub_categories=SubCategory::all();
    return view('mail.paymentSuccess')->with('sub_categories',$sub_categories);
}

public function getCancelPayment(Request $request){
    $sub_categories=SubCategory::all();
    return view('mail.paymentCancel')->with('sub_categories',$sub_categories);
}

public function postCancelPayment(Request $request){
    $sub_categories=SubCategory::all();
    return view('mail.paymentCancel')->with('sub_categories',$sub_categories);
}

public function siteMapReport(Request $request){
    $sub_categories=SubCategory::all();
    $reports = Report::where('status',1)->with('subCategory')->take(1000)->orderBy('report_id','desc')->get();
    return view('report.siteMapReports')->with('reports',$reports)->with('sub_categories',$sub_categories);
}

public function siteMapPressRelease(Request $request){
    $sub_categories=SubCategory::all();
    $news = News::orderBy('created_at','desc')->get();
    return view('public.siteMapPressRelease')->with('news',$news)->with('sub_categories',$sub_categories);
}

public function siteMapBlog(){
    $sub_categories=SubCategory::all();
    $articles = Article::orderBy('created_at','desc')->get();
    return view('public.siteMapBlog')->with('articles',$articles)->with('sub_categories',$sub_categories);
}


}